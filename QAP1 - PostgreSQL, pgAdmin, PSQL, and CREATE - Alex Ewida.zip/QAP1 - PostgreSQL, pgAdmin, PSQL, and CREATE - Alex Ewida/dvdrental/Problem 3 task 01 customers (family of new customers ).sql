INSERT INTO customer (first_name, last_name, store_id, email, address_id)
VALUES
   ('John', 'Dot', 1, 'john_5dot@hotmail.com',2),
   ('Jane', 'Dot', 1, 'jane_5dot@hotmail.com',2),
   ('Jim', 'Dot', 1, 'jim_5dot@hotmail.com',2),
   ('Jill', 'Dot', 1, 'jill_5dot@hotmail.com',2);