UPDATE customer
SET address_id = 4
       
WHERE last_name = 'Dot';