SELECT customer_id, first_name, last_name, email
FROM customer
ORDER BY last_name ASC;