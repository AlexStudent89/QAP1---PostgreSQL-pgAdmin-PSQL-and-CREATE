SELECT * 
FROM dvdrental_table_actor
ORDER BY actor_name DESC;
