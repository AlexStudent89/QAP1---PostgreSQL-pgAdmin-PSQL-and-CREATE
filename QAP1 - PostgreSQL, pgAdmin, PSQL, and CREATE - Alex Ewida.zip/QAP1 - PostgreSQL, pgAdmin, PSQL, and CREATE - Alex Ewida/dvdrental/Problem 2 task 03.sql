SELECT rating, COUNT(*)
FROM film
GROUP BY rating;