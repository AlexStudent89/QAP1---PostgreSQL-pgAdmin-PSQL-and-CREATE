DELETE FROM address
WHERE address_id = 1 

